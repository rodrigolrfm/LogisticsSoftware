from .Google import *
from .googleDriveAPI import *
from .utils import *

import tempfile

GAPI = GoogleAPI()

PATH_DATA = tempfile.gettempdir()
PARENT_FOLDERID_ARCHIVOS_ACTIVOS = "1sAGIghscMnTe8P80DkfirX6v56FrBZsy"
PARENT_FOLDERID_ARCHIVOS_ELIMINADOS = "1ornJalS4iEEa3wkDU-6e5ueppJ_UzPYL"
