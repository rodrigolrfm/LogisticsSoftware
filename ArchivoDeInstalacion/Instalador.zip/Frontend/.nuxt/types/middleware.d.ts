import type { NavigationGuard } from 'vue-router'
export type MiddlewareKey = string
declare module "D:/CICLO12/Tesis2/TesisSoftware/LogisticsSoftware/Frontend/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    middleware?: MiddlewareKey | NavigationGuard | Array<MiddlewareKey | NavigationGuard>
  }
}